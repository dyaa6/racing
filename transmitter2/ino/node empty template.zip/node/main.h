#ifndef Index_H
#define Index_H

#include <pgmspace.h>

const char index_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE html>
<html lang='ar'>
<head>
    <meta charset='UTF-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='minimal-ui,width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, height=device-height'>
    <title>Racing project</title>
<style>
    *{
    padding: 0px;
    margin: 0px;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    user-select: none;
}
:root {
  touch-action: pan-x pan-y;
  height: 100% 
}
*,
.button,
.button * {
-webkit-tap-highlight-color: transparent;
--bgColorMain:#1f1f23;
user-select: none;
}
:root{
	--button_color: #04AA6D;
}

body{
    background: var(--bgColorMain);
    background-size: cover;
    background-position: center;
    background-repeat: repeat;
    font-family: theme-font !important;
    font-size: large;
    --on: #88e661;
    --off: #f0f0f0;
    --transDur: 0.6s;
}








/*alert box*/
#alertContainer{
	width: 100%;
	position: fixed;
	left: 0px;
	bottom: 10vh;
	text-align: center;
	display: flex;
	justify-content: center;
}
.alertBox{
	width: 80%;
	height: 50px;
	line-height: 50px;
	background-color: #fff;
	border:1px solid red;
	border-radius: 10px;
	text-align: center;
	color: red;
	direction: rtl;
}






  





  


/*tap bar*/
html {
    box-sizing: border-box;
    --bgColorMenu : #333342;
    --duration: .7s;    

}




.menu{
    margin: 0;
	  padding: 0px;
    display: flex;
    /* Works well with 100% width  */
    width: 100% 	;
    font-size: large;
    position: fixed;
    bottom: 0px;
    left: 0px;
    align-items: center;
    justify-content: space-around;
    background-color: var(--bgColorMenu);
	  height: 60px;
}

.menu__item{
    all: unset;
    flex-grow: 1;
    z-index: 100;
    display: flex;
    cursor: pointer;
    position: relative;
    border-radius: 50%;
    align-items: center;
    will-change: transform;
    justify-content: center;
    padding: 0.55em 0 0.85em;
    transition: transform var(--timeOut , var(--duration));
	flex-direction: column;
    color:#fff;
	line-height: 1em;
}


.icon{
    width: 35px;
	height: 50;
    stroke: white;
    fill: transparent;
    stroke-width: 1pt;
    stroke-miterlimit: 10;
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke-dasharray: 400;
    
}

.menu__item.active .icon {

    animation: strok 1.5s reverse;
    stroke: #01fff4;
	color:#01fff4;
}
.menu__item.active{

	color:#01fff4;
}

@keyframes strok {

    100% {

        stroke-dashoffset: 400;

    }

}





@media screen and (max-width: 50em) {
    .menu{
        font-size: .8em;
    }
}
</style>


    
</head>

<body>


<div id='main-container'>
 




<div id='alertContainer'>
<div id='isconnected' class='alertBox'>
    لايوجد اتصال
</div></div>



</body>
<footer>

    <menu class='menu'>
    
        <button class='menu__item active' style='--bgColorItem: #ff8c00;' >
            <svg class='icon' viewBox='0 0 24 24'> <path d='M12,5.69l-7,7V19h5v-6h4v6h5v-6.31l-7-7Z' /> </svg>
            الرئيسية
        </button>
    
        <button class='menu__item' style='--bgColorItem: #f54888;' onclick='goSettings()'>
            <svg class='icon' viewBox='0 0 24 24'> 
                <path d='M19.14,12.94c.04-.3.06-.61.06-.94c0-.32-.02-.64-.06-.94l2.03-1.58a.49.49,0,0,0,.12-.61l-1.92-3.32a.48.48,0,0,0-.59-.22l-2.39,1c-.5-.38-1.03-.7-1.62-.94L14.4,2.81a.491.491,0,0,0-.49-.44H9.6a.49.49,0,0,0-.49.44L9,5.04c-.59.24-1.13.57-1.62.94l-2.39-1a.48.48,0,0,0-.59.22l-1.92,3.32c-.1.18-.03.39.12.61l2.03,1.58c-.04.3-.06.61-.06.94s.02.64.06.94l-2.03,1.58a.49.49,0,0,0-.12.61l1.92,3.32c.12.21.37.29.59.22l2.39-1c.5.38,1.03.7,1.62.94l.36,2.23a.49.49,0,0,0,.49.44h3.84a.49.49,0,0,0,.49-.44l.36-2.23c.59-.24,1.13-.57,1.62-.94l2.39,1c.22.08.47,0,.59-.22l1.92-3.32a.48.48,0,0,0-.12-.61Z' /> 
            </svg>
        الاعدادات
        </button>
    
      
    
    
      
    
    
      </menu>
    
   

</footer>

<script>
  const formatTime=(seconds)=> {
    if (isNaN(seconds) || seconds < 0) {
      return '-';
    }
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
  
    const formattedHours = hours < 10 ? `0${hours}` : `${hours}`;
    const formattedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
    const formattedSeconds = remainingSeconds < 10 ? `0${remainingSeconds}` : `${remainingSeconds}`;
  
    return `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
  }

setInterval(()=>{
        new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            const url = 'http://192.168.4.1/state';
            xhr.onreadystatechange = async() => {
              if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                  resolve(xhr.responseText);
                  document.getElementById('isconnected').style.display='none';

                  if(xhr.responseText.split('#')[0]=='on'){
                    document.getElementById('toggle1').checked = true;
                    document.getElementById('sign1').style.backgroundColor='red';
                    document.getElementById('image').src='image-G.png';
                  }
                  else{
                    document.getElementById('toggle1').checked = false;
                    document.getElementById('sign1').style.backgroundColor='#3c3838';
                    document.getElementById('image').src='image-R.png';
                    }
                  if(xhr.responseText.split('#')[1]=='on')
                    document.getElementById('sign3').style.backgroundColor='green';
                  else
                    document.getElementById('sign3').style.backgroundColor='#3c3838';
                  if(xhr.responseText.split('#')[2]=='on')
                    document.getElementById('run_sign').style.backgroundColor='green';
                  else
                     document.getElementById('run_sign').style.backgroundColor='#3c3838';
                     // set the timer
                  if(xhr.responseText.split('#')[3]!=undefined)
                    document.getElementById('timer').innerHTML=formatTime(parseInt(xhr.responseText.split('#')[3]));
                  else
                    setTimer('-');
                  
                } else {
                    document.getElementById('isconnected').style.display='block'; // no connection
                }
              }
            };
        
            xhr.open('GET', url, true);
            xhr.timeout = 400; // set the timeout to 2 seconds
            xhr.send();
          });
  }, 200);


const goSettings=()=>{
  window.open('settings.html', '_self');
}

const CenterLock=(ev)=>{
    new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        const url = ev;
    
        xhr.onreadystatechange = () => {
          if (xhr.readyState === 4) {
            if (xhr.status === 200) {
              resolve(xhr.responseText);
              document.getElementById('isconnected').style.display='none';
            } else {
              document.getElementById('isconnected').style.display='block'; // no connection
            }
          }
        };
    
        xhr.open('GET', url, true);
        xhr.timeout = 1000; // set the timeout to 2 seconds
        xhr.send();
      });
}

const switchOneOn=()=>{
  document.getElementById('image').src='image-G.png';
    new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        const url = 'http://2.2.2.2/switch1On';
    
        xhr.onreadystatechange = () => {
          if (xhr.readyState === 4) {
            if (xhr.status === 200) {
              resolve(xhr.responseText);
              document.getElementById('isconnected').style.display='none';
            } else {
              document.getElementById('isconnected').style.display='block'; // no connection
            }
          }
        };
    
        xhr.open('GET', url, true);
        xhr.timeout = 1000; // set the timeout to 2 seconds
        xhr.send();
      });
}

const switchOneOff=()=>{
  document.getElementById('image').src='image-R.png';
    new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        const url = 'http://2.2.2.2/switch1Off';
    
        xhr.onreadystatechange = () => {
          if (xhr.readyState === 4) {
            if (xhr.status === 200) {
              resolve(xhr.responseText);
              document.getElementById('isconnected').style.display='none';
            } else {
              document.getElementById('isconnected').style.display='block'; // no connection
            }
          }
        };
    
        xhr.open('GET', url, true);
        xhr.timeout = 1000; // set the timeout to 2 seconds
        xhr.send();
      });
}



const motorOn=()=>{
  new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const url = 'http://2.2.2.2/motorOn';

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          resolve(xhr.responseText);
          document.getElementById('isconnected').style.display='none'; 
        } else {
          document.getElementById('isconnected').style.display='block'; // no connection
        }
      }
    };

    xhr.open('GET', url, true);
    xhr.timeout = 400; 
    xhr.send();
  });
}
const motorOff=()=>{
  new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const url = 'http://192.168.4.1/motorOff';

    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          resolve(xhr.responseText);
          document.getElementById('isconnected').style.display='none'; 
        } else {
          document.getElementById('isconnected').style.display='block'; // no connection
        }
      }
    };

    xhr.open('GET', url, true);
    xhr.timeout = 400; 
    xhr.send();
  });
}

const switch1=document.getElementById('toggle1');
switch1.addEventListener('change',()=>{
    if(switch1.checked) switchOneOn();
    else switchOneOff();
})



const lock=document.getElementById('lock_btn');
lock.addEventListener('touchstart',()=>{CenterLock('lock')});

const open=document.getElementById('open_btn');
open.addEventListener('touchstart',()=>{CenterLock('open')});

const trunk=document.getElementById('trunk_btn');
trunk.addEventListener('touchstart',()=>{CenterLock('trunk')});

const glass=document.getElementById('jam_btn');
glass.addEventListener('touchstart', ()=>{CenterLock('glassUP')});
glass.addEventListener('touchend', ()=>{CenterLock('glassDown')});


const runButton=document.getElementById('run_btn');
runButton.addEventListener('touchstart', motorOn);
runButton.addEventListener('touchend', motorOff);

document.getElementById('image').addEventListener('contextmenu', function(e) {
    e.preventDefault();
  });
document.getElementById('lock_btn').addEventListener('contextmenu', function(e) {
  e.preventDefault();
});
document.getElementById('open_btn').addEventListener('contextmenu', function(e) {
  e.preventDefault();
});
document.getElementById('jam_btn').addEventListener('contextmenu', function(e) {
  e.preventDefault();
});
document.getElementById('trunk_btn').addEventListener('contextmenu', function(e) {
  e.preventDefault();
});
document.addEventListener('touchmove', function (event) {// to prevent the zoom
  if (event.scale !== 1) { event.preventDefault(); }
}, { passive: false });
    </script>
</html>
)rawliteral";

#endif // Index_H
